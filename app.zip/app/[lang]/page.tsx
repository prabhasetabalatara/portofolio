import { getDictionary } from '@/lib/dictionaries';
import { TypewriterSection } from './_components/TypewriterSection';
import { InteractiveImageSection } from './_components/InteractiveImageSection';

export default async function HomePage({
  params,
}: {
  params: Promise<{ lang: 'en' | 'id' }>;
}) {
  const { lang } = await params;
  const dict = await getDictionary(lang);

  return (
    <div className="flex min-h-screen items-center justify-center px-8 md:px-16 lg:px-24 
                    bg-gradient-to-br from-gray-50 to-gray-100 
                    dark:from-gray-900 dark:to-gray-800 
                    transition-all duration-500">
      <div className="container mx-auto flex flex-col md:flex-row items-center justify-center gap-16 py-20">
        
        <div className="w-full md:w-1/2 text-center md:text-left">
          <TypewriterSection content={dict.home.leftColumn} />
        </div>
        
        <div className="w-full md:w-1/2 flex justify-center order-first md:order-last">
          <InteractiveImageSection />
        </div>
      </div>
    </div>
  );
}
