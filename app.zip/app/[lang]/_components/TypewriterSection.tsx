'use client';

import { useState, useEffect } from 'react';

interface TypewriterSectionProps {
  content: {
    title: string;
    subtitle: string;
    description: string;
  };
}

export function TypewriterSection({ content }: TypewriterSectionProps) {
  const [displayedText, setDisplayedText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTyping, setIsTyping] = useState(true);

  useEffect(() => {
    if (currentIndex < content.title.length) {
      const timer = setTimeout(() => {
        setDisplayedText(content.title.slice(0, currentIndex + 1));
        setCurrentIndex(currentIndex + 1);
      }, 100);
      return () => clearTimeout(timer);
    } else {
      setIsTyping(false);
    }
  }, [currentIndex, content.title]);

  return (
    <div className="space-y-6">
      <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold 
                     bg-gradient-to-r from-blue-600 to-purple-600 
                     dark:from-blue-400 dark:to-purple-400 
                     bg-clip-text text-transparent">
        {displayedText}
        {isTyping && (
          <span className="animate-pulse text-gray-900 dark:text-gray-100">|</span>
        )}
      </h1>
      
      <h2 className="text-xl md:text-2xl lg:text-3xl font-medium 
                     text-gray-700 dark:text-gray-300 
                     transition-colors duration-300">
        {content.subtitle}
      </h2>
      
      <p className="text-base md:text-lg lg:text-xl 
                    text-gray-600 dark:text-gray-400 
                    leading-relaxed transition-colors duration-300">
        {content.description}
      </p>
      
      <div className="flex flex-col sm:flex-row gap-4 mt-8">
        <button className="px-8 py-3 bg-blue-600 hover:bg-blue-700 
                          dark:bg-blue-500 dark:hover:bg-blue-600 
                          text-white font-medium rounded-lg 
                          transition-all duration-200 
                          transform hover:scale-105 hover:shadow-lg">
          Get Started
        </button>
        
        <button className="px-8 py-3 border-2 border-blue-600 dark:border-blue-500 
                          text-blue-600 dark:text-blue-400 
                          hover:bg-blue-600 hover:text-white 
                          dark:hover:bg-blue-500 dark:hover:text-white 
                          font-medium rounded-lg 
                          transition-all duration-200 
                          transform hover:scale-105">
          Learn More
        </button>
      </div>
    </div>
  );
}
