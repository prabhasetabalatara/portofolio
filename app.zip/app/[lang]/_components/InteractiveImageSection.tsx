'use client';

import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export function InteractiveImageSection() {
  const [currentImage, setCurrentImage] = useState(0);
  
  const images = [
    '/api/placeholder/400/300',
    '/api/placeholder/400/300',
    '/api/placeholder/400/300',
  ];

  const nextImage = () => {
    setCurrentImage((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentImage((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <div className="relative group">
      <div className="relative overflow-hidden rounded-2xl shadow-2xl 
                      bg-white dark:bg-gray-800 
                      transition-all duration-300 
                      hover:shadow-blue-500/25 dark:hover:shadow-blue-400/25">
        <img
          src={images[currentImage]}
          alt={`Slide ${currentImage + 1}`}
          className="w-full h-80 object-cover transition-transform duration-500 
                     group-hover:scale-105"
        />
        
        {/* Navigation buttons */}
        <button
          onClick={prevImage}
          className="absolute left-4 top-1/2 -translate-y-1/2 
                     w-10 h-10 rounded-full 
                     bg-white/80 dark:bg-gray-800/80 
                     hover:bg-white dark:hover:bg-gray-700 
                     text-gray-900 dark:text-gray-100 
                     flex items-center justify-center 
                     transition-all duration-200 
                     opacity-0 group-hover:opacity-100 
                     transform -translate-x-2 group-hover:translate-x-0"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        
        <button
          onClick={nextImage}
          className="absolute right-4 top-1/2 -translate-y-1/2 
                     w-10 h-10 rounded-full 
                     bg-white/80 dark:bg-gray-800/80 
                     hover:bg-white dark:hover:bg-gray-700 
                     text-gray-900 dark:text-gray-100 
                     flex items-center justify-center 
                     transition-all duration-200 
                     opacity-0 group-hover:opacity-100 
                     transform translate-x-2 group-hover:translate-x-0"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
      
      {/* Dots indicator */}
      <div className="flex justify-center mt-4 space-x-2">
        {images.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentImage(index)}
            className={`w-3 h-3 rounded-full transition-all duration-200 ${
              index === currentImage
                ? 'bg-blue-600 dark:bg-blue-400 scale-125'
                : 'bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
