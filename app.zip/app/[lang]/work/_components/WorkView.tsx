'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';

type Project = {
  slug: string;
  title: string;
  category: string;
  thumbnail: string;
  summary: string;
};

export default function WorkView({ projects, lang }: { projects: Project[], lang: 'id' | 'en' }) {
  const allCategories = [lang === 'id' ? 'Semua' : 'All', ...Array.from(new Set(projects.map(p => p.category)))];
  const [filter, setFilter] = useState(allCategories[0]);

  const filteredProjects = filter === allCategories[0]
    ? projects
    : projects.filter(p => p.category === filter);

  return (
    <>
      {/* Tombol Filter */}
      <div className="flex justify-center gap-2 sm:gap-4 mb-12 flex-wrap">
        {allCategories.map(category => (
          <button
            key={category}
            onClick={() => setFilter(category)}
            className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors ${
              filter === category
                ? 'bg-cyan-500 text-white'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Grid Proyek */}
      <div className="grid gap-8 md:grid-cols-2">
        {filteredProjects.map((project, index) => (
          <motion.div
            key={project.slug}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Link href={`/${lang}/work/${project.slug}`}>
              <div className="bg-gray-800/50 rounded-2xl border border-gray-700 overflow-hidden group h-full flex flex-col">
                <div className="relative w-full h-60">
                  <Image
                    src={project.thumbnail}
                    alt={project.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6 flex-grow flex flex-col">
                  <span className="text-sm font-semibold text-cyan-400 mb-1">{project.category}</span>
                  <h3 className="text-2xl font-bold text-white mb-3">{project.title}</h3>
                  <p className="text-gray-400 flex-grow">{project.summary}</p>
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </>
  );
}
