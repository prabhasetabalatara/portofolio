import { getGalleryImages } from '@/lib/gallery';
import GalleryView from './_components/GalleryView';

export default function GalleryPage({
  params: { lang },
}: {
  params: { lang: 'en' | 'id' };
}) {
  const images = getGalleryImages();

  return (
    <div className="container mx-auto px-6 py-24 sm:py-32 lg:px-8">
      {/* Judul Halaman */}
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
          {lang === 'id' ? 'Galeri Karya' : 'Work Gallery'}
        </h1>
        <p className="mt-4 text-lg leading-8 text-gray-400">
          {lang === 'id' ? 'Koleksi desain, branding, dan ilustrasi yang pernah saya buat.' : 'A collection of designs, branding, and illustrations I have created.'}
        </p>
      </div>

      {/* Tampilkan komponen interaktif galeri */}
      <GalleryView images={images} lang={lang} />
    </div>
  );
}
