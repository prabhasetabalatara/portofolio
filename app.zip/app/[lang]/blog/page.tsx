import { getAllPosts } from '@/lib/posts';
import { getDictionary } from '@/lib/dictionaries';
import Link from 'next/link';
import { Calendar, User } from 'lucide-react';

// Tambahkan 'async' ke definisi fungsi
export default async function BlogPage({
  params: { lang },
}: {
  params: { lang: 'en' | 'id' };
}) {
  const posts = getAllPosts(lang);
  const dict = await getDictionary(lang);
  const content = dict.blogPage;

  return (
    <div className="container mx-auto px-6 py-24 sm:py-32 lg:px-8">
      {/* Judul Halaman */}
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
          {content.title}
        </h1>
        <p className="mt-4 text-lg leading-8 text-gray-400">
          {content.subtitle}
        </p>
      </div>

      {/* Daftar Postingan */}
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {posts.map((post: any) => (
          <Link key={post.slug} href={`/${lang}/blog/${post.slug}`}>
            <div className="bg-gray-800/50 p-6 rounded-2xl border border-gray-700 hover:border-cyan-400 transition-all duration-300 h-full flex flex-col">
              <h2 className="text-2xl font-bold text-white mb-3">{post.title}</h2>
              <p className="text-gray-400 mb-4 flex-grow">{post.summary}</p>
              <div className="flex items-center justify-between text-sm text-gray-500 mt-auto">
                <div className="flex items-center gap-2">
                  <User size={14} />
                  <span>{post.author}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar size={14} />
                  <span>{new Date(post.date).toLocaleDateString(lang)}</span>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
