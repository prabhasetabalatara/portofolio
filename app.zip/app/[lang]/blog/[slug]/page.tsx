import { getPostBySlug } from '@/lib/posts';
import { notFound } from 'next/navigation';
import { MDXRemote } from 'next-mdx-remote/rsc';
import { Calendar, User } from 'lucide-react';

// Komponen kustom untuk merender elemen MDX jika diperlukan
const components = {
  // Contoh: h2: (props) => <h2 className="text-2xl font-bold text-cyan-400" {...props} />,
};

export default async function BlogPostPage({
  params,
}: {
  params: { slug: string; lang: 'id' | 'en' };
}) {
  const post = await getPostBySlug(params.slug, params.lang);

  if (!post) {
    notFound();
  }

  return (
    <div className="container mx-auto px-6 py-24 sm:py-32 lg:px-8">
      <article className="prose prose-invert prose-lg mx-auto">
        {/* Header Artikel */}
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white">{post.meta.title}</h1>
          <div className="flex items-center justify-center gap-6 mt-6 text-gray-400">
            <div className="flex items-center gap-2">
              <User size={16} />
              <span>{post.meta.author}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar size={16} />
              <span>{new Date(post.meta.date).toLocaleDateString(params.lang)}</span>
            </div>
          </div>
        </div>

        {/* Konten MDX */}
        <MDXRemote source={post.content} components={components} />
      </article>
    </div>
  );
}
