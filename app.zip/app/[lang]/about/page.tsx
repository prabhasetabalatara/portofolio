import { getDictionary } from '@/lib/dictionaries';
import Image from 'next/image';
import Link from 'next/link';
import { Briefcase, Code, Figma, GitBranch, GraduationCap, Wind } from 'lucide-react';

export default async function AboutPage(props: {
  params: { lang: 'en' | 'id' };
}) {
  const { lang } = props.params;
  const dict = await getDictionary(lang);
  const content = dict.aboutPage;

  const skills = [
    { name: "Figma", icon: <Figma size={32} className="text-pink-500" /> },
    { name: "React", icon: <Code size={32} className="text-cyan-400" /> },
    { name: "Next.js", icon: <Code size={32} className="text-gray-800 dark:text-white" /> },
    { name: "JavaScript", icon: <Code size={32} className="text-yellow-400" /> },
    { name: "TypeScript", icon: <Code size={32} className="text-blue-500" /> },
    { name: "Tailwind CSS", icon: <Wind size={32} className="text-teal-400" /> },
    { name: "Node.js", icon: <Code size={32} className="text-green-500" /> },
    { name: "Git", icon: <GitBranch size={32} className="text-orange-500" /> },
  ];

  return (
    <div className="container mx-auto px-6 py-24 sm:py-32 lg:px-8">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-6xl">{content.title}</h1>
        <p className="mt-4 text-lg leading-8 text-gray-600 dark:text-gray-400">{content.subtitle}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 items-center mb-24">
        <div className="lg:col-span-2">
          <div className="aspect-square relative rounded-2xl overflow-hidden shadow-2xl">
            <Image
              src="/images/profile-placeholder.png"
              alt="Foto Profil"
              fill
              className="object-cover"
            />
          </div>
        </div>
        <div className="lg:col-span-3">
          <h2 className="text-3xl font-bold text-cyan-500 dark:text-cyan-400 mb-4">{content.bioTitle}</h2>
          <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-4">
            {content.bio.replace('[Nama Kamu]', dict.home.leftColumn.name)}
          </p>
          <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{content.bio2}</p>
        </div>
      </div>

      <div className="mb-24">
        <h2 className="text-3xl font-bold text-center mb-12 text-cyan-500 dark:text-cyan-400">{content.skillsTitle}</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-8">
          {skills.map((skill) => (
            <div key={skill.name} className="flex flex-col items-center gap-3 p-4 bg-gray-100 dark:bg-gray-800/50 rounded-xl border border-gray-200 dark:border-gray-700 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
              {skill.icon}
              <span className="text-sm font-medium text-gray-800 dark:text-white">{skill.name}</span>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-3xl font-bold text-center mb-12 text-cyan-500 dark:text-cyan-400">{content.experienceTitle}</h2>
        <div className="relative border-l-2 border-cyan-500/30 ml-6">
          {content.timeline.map((item: any, index: number) => (
            <div key={index} className="mb-10 ml-10">
              <span className="absolute flex items-center justify-center w-8 h-8 bg-gray-100 dark:bg-gray-800 rounded-full -left-4 border-2 border-cyan-500">
                {item.role.includes('Pengembang') || item.role.includes('Developer') ? (
                  <Briefcase className="w-4 h-4 text-cyan-500 dark:text-cyan-400" />
                ) : (
                  <GraduationCap className="w-4 h-4 text-cyan-500 dark:text-cyan-400" />
                )}
              </span>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{item.role}</h3>
              <p className="block mb-2 text-sm font-normal leading-none text-gray-600 dark:text-gray-400">
                {item.company} | {item.date}
              </p>
              <p className="text-base font-normal text-gray-700 dark:text-gray-300">{item.description}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-24 text-center bg-gray-100 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 rounded-2xl p-12">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">{content.ctaTitle}</h2>
        <Link href={`/${lang}/work`} className="mt-6 inline-block bg-cyan-500 text-white font-bold py-3 px-8 rounded-lg hover:bg-cyan-600 transition-all transform hover:scale-105">
          {content.ctaButton}
        </Link>
      </div>
    </div>
  );
}
